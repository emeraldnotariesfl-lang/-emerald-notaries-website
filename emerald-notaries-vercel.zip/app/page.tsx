'use client';
import EmeraldNotariesSite from '../EmeraldNotariesSite';
export default function Page() { return <EmeraldNotariesSite />; }
